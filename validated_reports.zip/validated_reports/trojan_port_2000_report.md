# TCP/2000 Remote Control Service Exposure

## Description
TCP port 2000—commonly abused by remote-control malware and backdoor frameworks—remains open across several management servers. The service replies to generic probes (`tcpwrapped`), indicating a listening daemon but no authentication during handshake. Without hardening, an attacker with network access can brute-force or enumerate the service to gain unauthorized control.

## Observation
- `nmap -sV -p 2000` reported an open listener on `10.32.125.11`, `10.32.125.14`, `10.32.125.21`, `10.32.124.66`, and `192.168.1.3` (the filtered gateway `10.32.124.1` drops probes).
- SYN+FIN and SYN+ECE tests confirm weak firewall enforcement around the service, increasing exploitation risk.

## Impact
- Remote-control backdoors (e.g., Cisco SCCP-based malware) can receive commands without authentication.
- Exposure assists lateral movement into remote access platforms (RDP/Splashtop).

## Ease of Exploitation
**Easy** – Banner grabbing with tools like nmap reveals the service; no credentials are required.

## Affected Assets
- 10.32.124.66
- 10.32.125.11
- 10.32.125.14
- 10.32.125.21
- 192.168.1.3

## CVSS v3.1
**Score:** 6.5 (Medium)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N`

## Recommendations
1. Identify the legitimate owner of TCP/2000 on each host (Citrix/remote assistance/etc.) and determine whether it is required.
2. If the service is needed, restrict access with host-based firewalls and enforce authentication or VPN segmentation.
3. Monitor logs for inbound connections to TCP/2000 and alert on anomalous source IPs.

## References
- [Cisco Port 2000 Usage Advisory](https://www.cisco.com/c/en/us/support/docs/security-vpn/ip-telephony-ports.html)
- [Tenable Plugin 11157 – Trojan Horse Detection](https://www.tenable.com/plugins/nessus/11157)

## Proof of Concept
```
nmap -Pn -sV -p 2000 10.32.125.21
PORT     STATE SERVICE    VERSION
2000/tcp open  tcpwrapped

nmap -Pn -sV -p 2000 192.168.1.3
PORT     STATE SERVICE    VERSION
2000/tcp open  cisco-sccp
```
