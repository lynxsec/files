# Unhardened IIS/HTTP Service Exposure

## Description
Multiple web services expose default IIS content or detailed error banners, leaking server metadata and indicating incomplete hardening. Such information eases reconnaissance and may reveal unpatched modules. In addition, the Splashtop HTTP listener returns bare Microsoft-HTTPAPI/2.0 errors, confirming that the service responds without authentication.

## Observation
- `curl http://10.32.125.11` and `curl http://10.32.125.23` both return the default “IIS Windows Server” landing page.
- `curl -I http://10.32.125.11` discloses `Server: Microsoft-IIS/10.0` headers.
- `curl -I http://10.32.124.66` responds with `Server: Microsoft-HTTPAPI/2.0` and 404 error body, revealing framework details.

## Impact
- Provides attackers with server version details that guide exploit selection.
- Indicates minimal hardening; default content may expose sample scripts or configuration files.
- Unauthenticated HTTPAPI responses increase the risk of brute force toward Splashtop or management interfaces.

## Ease of Exploitation
**Easy** – Information is disclosed via unauthenticated HTTP requests.

## Affected Assets
- 10.32.125.11 (IIS default site)
- 10.32.125.23 (IIS default site)
- 10.32.124.66 (HTTPAPI exposure)

## CVSS v3.1
**Score:** 4.3 (Medium)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N`

## Recommendations
1. Replace default IIS content with custom applications or disable the site if unused.
2. Sanitize response headers (remove `Server`, `X-Powered-By`) via URL Rewrite or reverse proxies.
3. For Microsoft-HTTPAPI endpoints, require authentication or move them behind a VPN/reverse proxy.

## References
- [Microsoft IIS Hardening Checklist](https://learn.microsoft.com/en-us/iis/get-started/planning-for-security/)
- [OWASP Testing Guide – Information Disclosure](https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Information_Gathering/01-Testing_for_Information_Disclosure)

## Proof of Concept
```
curl -I http://10.32.125.11
HTTP/1.1 200 OK
Server: Microsoft-IIS/10.0

curl http://10.32.125.23 | head -n 5
<title>IIS Windows Server</title>

curl -I http://10.32.124.66
HTTP/1.1 404 Not Found
Server: Microsoft-HTTPAPI/2.0
```
