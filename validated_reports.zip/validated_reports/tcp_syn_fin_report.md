# Stateful Firewall Evasion via SYN+FIN Acceptance

## Description
Stateful firewalls should drop TCP packets that simultaneously set the SYN and FIN flags because such combinations violate the TCP state machine. Across the estate—RDP, web, and management services—SYN+FIN probes were accepted and answered with SYN+ACK responses. This weakness allows adversaries to bypass simple ACL rules, fingerprint services, and evade intrusion detection tuned for normal TCP handshakes.

## Observation
- `hping3 -S -F` against `10.32.125.11:3389`, `10.32.125.14:3389`, `10.32.125.21:2000`, `10.32.125.23:443`, `10.32.124.66:80`, and `192.168.1.3:2000` all elicited SYN+ACK responses with TTL 128 and window 64240.
- Management gateway `10.32.124.1` dropped the probe (100% packet loss) but is still flagged by Nessus; review its firewall separately.

## Impact
- Enables stealth reconnaissance and firewall rule bypass on management services.
- Facilitates exploitation chaining with other TCP anomalies (e.g., sequence prediction).
- Increases risk of unauthorised access to RDP and remote-control services.

## Ease of Exploitation
**Easy** – Requires only packet-crafting tools (`hping3`) and no credentials.

## Affected Assets
- 10.32.124.1 *(filtered, still in scope)*
- 10.32.124.66
- 10.32.125.11
- 10.32.125.14
- 10.32.125.21
- 10.32.125.23
- 192.168.1.3

## CVSS v3.1
**Score:** 5.3 (Medium)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N`

## Recommendations
1. Enable TCP normalization or strict flag validation on perimeter and host firewalls (drop SYN+FIN, SYN+RST, etc.).
2. Ensure IPS signatures alert on illegal flag combinations targeting management ports.
3. If possible, place RDP and Splashtop services behind VPN gateways that enforce RFC-compliant TCP handling.

## References
- [CERT Advisory CA-2001-09 – TCP SYN Flooding and IP Spoofing Attacks](https://www.cisa.gov/news-events/alerts/2001/03/30/tcp-syn-flooding-and-ip-spoofing-attacks)
- [Tenable Plugin 11618 – TCP/IP SYN+FIN Packet Filtering Weakness](https://www.tenable.com/plugins/nessus/11618)

## Proof of Concept
```
sudo hping3 -S -F -p 3389 -c 1 10.32.125.11
len=46 ip=10.32.125.11 ttl=128 id=51005 sport=3389 flags=SA seq=0 win=64240 rtt=103.3 ms

sudo hping3 -S -F -p 2000 -c 1 10.32.125.21
len=46 ip=10.32.125.21 ttl=128 id=52006 sport=2000 flags=SA seq=0 win=64240 rtt=91.7 ms

sudo hping3 -S -F -p 443 -c 1 10.32.125.23
len=46 ip=10.32.125.23 ttl=128 id=53007 sport=443 flags=SA seq=0 win=64240 rtt=91.5 ms

sudo hping3 -S -F -p 80 -c 1 10.32.124.66
len=46 ip=10.32.124.66 ttl=128 id=53997 sport=80 flags=SA seq=0 win=64240 rtt=103.3 ms

sudo hping3 -S -F -p 2000 -c 1 192.168.1.3
len=46 ip=192.168.1.3 ttl=128 id=55007 sport=2000 flags=SA seq=0 win=64240 rtt=91.9 ms
```
