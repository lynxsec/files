# Insecure TLS Certificate Deployment

## Description
Multiple management services present self-signed or expired TLS certificates, and one RDP service still uses a SHA1 signature. These weaknesses allow adversaries to stage man-in-the-middle attacks by presenting spoofed certificates without triggering strict validation, and can break modern clients that enforce SHA256+ and valid lifetimes. The Splashtop endpoint on `10.32.124.66:6783` is particularly risky: its certificate expired in 2020, is self-signed, and advertises a mismatched Common Name (`Splashtop Inc. Self CA`), making users more likely to click through warnings and accept malicious proxies.

## Observation
- `10.32.125.11:3389` – Self-signed RDP certificate (`CN=IADDC01.solomonedwards.com`).
- `10.32.125.11:636` – Self-signed LDAPS certificate.
- `10.32.125.14:3389` – Self-signed RDP certificate.
- `10.32.124.66:3389` – Self-signed SHA1 RDP certificate (`Peer signing digest: SHA1`).
- `10.32.124.66:6783` – Self-signed Splashtop certificate, expired `Feb  2 2020`, CN mismatch (`Splashtop Inc. Self CA`).

## Impact
- Users can be tricked into accepting spoofed certificates, enabling credential theft and session hijacking.
- Noncompliant certificates violate industry regulations (PCI DSS, NIST) and may break future client updates.
- Expired or self-signed certificates allow downgrade attacks that keep legacy encryption in play.

## Ease of Exploitation
**Easy** – Attackers only need network access to present a rogue certificate and exploit user trust; no authentication required.

## Affected Assets
- 10.32.125.11 (RDP/LDAPS)
- 10.32.125.14 (RDP)
- 10.32.124.66 (RDP & Splashtop 6783)

## CVSS v3.1
**Score:** 6.5 (Medium)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N`

## Recommendations
1. Replace self-signed certificates with ones issued by a trusted internal or public Certificate Authority and ensure SANs/CNs include the service hostname.
2. Reissue RDP certificates using SHA-256 or stronger digests; disable SHA1 templates in Active Directory Certificate Services.
3. Renew the Splashtop certificate immediately (CN must match the service endpoint) and monitor for upcoming expirations.
4. Deploy certificate-monitoring alerts so services are renewed before expiry.

## References
- [Mozilla Security/Server Side TLS Guidelines](https://wiki.mozilla.org/Security/Server_Side_TLS)
- [Microsoft KB 2783202 – RDP Certificate Hardening](https://support.microsoft.com/help/2783202)
- [Splashtop TLS Certificate Requirements](https://support-splashtopbusiness.splashtop.com/hc/en-us/articles/115004979786)

## Proof of Concept
```
# 10.32.124.66:6783 (expired, wrong host)
echo | openssl s_client -connect 10.32.124.66:6783 -showcerts
verify error:num=10:certificate has expired
subject=C = UK, CN = Splashtop Inc. Self CA
issuer=C = UK, CN = Splashtop Inc. Self CA
notAfter=Feb  2 04:10:14 2020 GMT

# 10.32.124.66:3389 (SHA1 self-signed)
echo | openssl s_client -connect 10.32.124.66:3389 -showcerts
Peer signing digest: SHA1
subject=CN = PHLSQL05.solomonedwards.com (self-signed)

# 10.32.125.11:636 (self-signed LDAPS)
echo | openssl s_client -connect 10.32.125.11:636 -showcerts
verify error:num=21:unable to verify the first certificate
subject=CN = iaddc01.solomonedwards.com

# 10.32.125.14:3389 (self-signed RDP)
echo | openssl s_client -connect 10.32.125.14:3389 -showcerts
verify error:num=21:unable to verify the first certificate
```
