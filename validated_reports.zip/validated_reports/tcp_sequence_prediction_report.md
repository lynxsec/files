# Predictable TCP Sequence/IP ID Values Permit Blind Resets

## Description
Key internal endpoints respond to bursts of TCP SYN probes with sequential IP identification numbers and predictable sequence values. This behaviour enables blind TCP reset or injection attacks (CVE‑2004‑0230), allowing an off-path adversary to disrupt RDP, HTTP, or custom management sessions without authenticating. The exposure spans every reachable server in scope, aside from the filtered gateway `10.32.124.1`.

## Observation
- `hping3 --fast` probes against RDP (3389), web (80/443) and custom services consistently produced sequential IP IDs.
- Example sequences:
  - `10.32.125.11:3389` → IDs 54566, 54567, 54568
  - `10.32.124.66:80`    → IDs 53582, 53583, 53584
  - `192.168.1.3:2000`   → IDs 55507, 55508, 55509
- `10.32.124.1` remained filtered, but Nessus flagged it; review its OS level mitigation separately.

## Impact
- Off-path attackers can send forged RST packets to terminate VPN/RDP sessions.
- Predictable sequence numbers make it easier to inject commands into long-lived TCP streams.

## Ease of Exploitation
**Moderate** – Requires packet-crafting tools and the ability to observe response behaviour but no credentials.

## Affected Assets
- 10.32.124.66
- 10.32.125.11
- 10.32.125.14
- 10.32.125.21
- 10.32.125.23
- 192.168.1.3

## CVSS v3.1
**Score:** 5.3 (Medium)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N`

## Recommendations
1. Enable TCP/IP stack hardening that randomises IP IDs and challenge ACKs (e.g., Microsoft KB 893066, Linux `tcp_challenge_ack_limit`).
2. Prefer encrypted tunnels (TLS, SSH, VPN) for management sessions so injected resets are less impactful.
3. Configure firewalls/IDS to rate-limit or detect abnormal SYN bursts that target management ports.

## References
- [CERT VU#415294 – TCP/IP Predictable IP ID Vulnerability](https://www.kb.cert.org/vuls/id/415294)
- [Microsoft Security Advisory 899599 – TCP/IP Vulnerability](https://docs.microsoft.com/en-us/security-updates/securitybulletins/2005/ms05-019)

## Proof of Concept
```
sudo hping3 -S -p 3389 -c 3 --fast 10.32.125.11
len=46 ip=10.32.125.11 ttl=128 id=54566 flags=SA
len=46 ip=10.32.125.11 ttl=128 id=54567 flags=SA
len=46 ip=10.32.125.11 ttl=128 id=54568 flags=SA

sudo hping3 -S -p 80 -c 3 --fast 10.32.124.66
len=46 ip=10.32.124.66 ttl=128 id=53582 flags=SA
len=46 ip=10.32.124.66 ttl=128 id=53583 flags=SA
len=46 ip=10.32.124.66 ttl=128 id=53584 flags=SA

sudo hping3 -S -p 2000 -c 3 --fast 192.168.1.3
len=46 ip=192.168.1.3 ttl=128 id=55507 flags=SA
len=46 ip=192.168.1.3 ttl=128 id=55508 flags=SA
len=46 ip=192.168.1.3 ttl=128 id=55509 flags=SA
```
