# Legacy TLS Protocols and Weak Cipher Support

## Description
The Splashtop service on `10.32.124.66:6783` allows deprecated TLS protocols (1.0 and 1.1) and advertises 64-bit block ciphers (IDEA/SEED) susceptible to SWEET32 attacks. Support for these obsolete configurations allows attackers to force downgrade handshakes or recover portions of encrypted traffic during long-lived sessions.

## Observation
- `nmap --script ssl-enum-ciphers -p 6783 10.32.124.66` lists IDEA/SEED ciphers for TLS1.0–TLS1.2 with warnings about SWEET32.
- `openssl s_client -tls1` / `-tls1_1` / `-tls1_2` all negotiate successfully, confirming legacy protocol support.

## Impact
- Downgrade attacks can force older protocol versions, enabling interception of Splashtop traffic.
- SWEET32 (64-bit block cipher) exposure allows recovery of plaintext in long-lived sessions.
- Noncompliance with modern TLS baselines may block future client connections or fail audits.

## Ease of Exploitation
**Moderate** – Requires the attacker to maintain a long-running session or coerce downgrade, but tooling is widely available.

## Affected Assets
- 10.32.124.66 (Splashtop service on TCP/6783)

## CVSS v3.1
**Score:** 5.9 (Medium)  
**Vector:** `AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:N`

## Recommendations
1. Disable TLS 1.0 and TLS 1.1 on the Splashtop gateway; require TLS 1.2+ with modern AEAD ciphers (AES-GCM, ChaCha20-Poly1305).
2. Remove IDEA/SEED/3DES cipher suites from the allowed list.
3. After reconfiguration, rescan with `ssl-enum-ciphers` to confirm only strong protocols/ciphers remain.

## References
- [RFC 8996 – Deprecating TLS 1.0 and TLS 1.1](https://datatracker.ietf.org/doc/html/rfc8996)
- [OpenSSL SWEET32 Advisory](https://www.openssl.org/blog/blog/2016/08/24/sweet32/)

## Proof of Concept
```
nmap -Pn --script ssl-enum-ciphers -p 6783 10.32.124.66
|   TLSv1.0:
|       TLS_RSA_WITH_IDEA_CBC_SHA  (64-bit block)
|       TLS_RSA_WITH_SEED_CBC_SHA  (64-bit block)
|
openssl s_client -tls1 -connect 10.32.124.66:6783 </dev/null | grep 'Protocol'
    Protocol  : TLSv1

openssl s_client -tls1_1 -connect 10.32.124.66:6783 </dev/null | grep 'Protocol'
    Protocol  : TLSv1.1
```
