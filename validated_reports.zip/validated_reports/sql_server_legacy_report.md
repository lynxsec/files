# Unsupported and Unpatched SQL Server 2012 Deployment

## Description
The SQL Server instance on `10.32.124.66` is running Microsoft SQL Server 2012 SP3 (build 11.00.7507.00). SQL Server 2012 reached end of support in July 2022, so the platform no longer receives security updates. The instance therefore misses the February and April 2023 security rollups that address multiple remote code execution vulnerabilities.

## Observation
- `nmap -sV --script ms-sql-info -p 1433 10.32.124.66` reports `Microsoft SQL Server 2012 SP3+ (11.00.7507.00)`.
- `sudo nmap -sU --script ms-sql-info -p 1434 10.32.124.66` returns the same version via SQL Browser.
- Tenable plugins 171603/175451 highlight missing security rollups (CVE‑2023‑21528, CVE‑2023‑23384, etc.).

## Impact
- Remote code execution vulnerabilities patched in 2023 remain exploitable, enabling full database takeover.
- Unsupported software violates lifecycle/compliance requirements and leaves future bugs unpatched.
- Compromise of the database service exposes sensitive application data and credentials.

## Ease of Exploitation
**Moderate** – Public exploit code exists for several SQL Server flaws; attacker needs network access to TCP/1433.

## Affected Assets
- 10.32.124.66 (MSSQLSERVER instance)

## CVSS v3.1
**Score:** 9.8 (Critical)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H`

## Recommendations
1. Plan an upgrade to a supported SQL Server release (2019 or 2022) or migrate workloads to Azure SQL.
2. If immediate upgrade is not possible, apply the latest GDR rollups (≥11.0.7518) and restrict TCP/1433 to trusted management networks.
3. Enable SQL auditing/monitoring to detect exploitation attempts until the upgrade is completed.

## References
- [Microsoft Lifecycle – SQL Server 2012](https://learn.microsoft.com/lifecycle/products/sql-server-2012)
- [Microsoft SQL Server 2012 SP4 Security Update (KB5029375)](https://support.microsoft.com/help/5029375)

## Proof of Concept
```
nmap -Pn -sV -p 1433 --script ms-sql-info 10.32.124.66
|   Version: name: Microsoft SQL Server 2012 SP3+
|            number: 11.00.7507.00

sudo nmap -Pn -sU -p 1434 --script ms-sql-info 10.32.124.66
|   Instance name: MSSQLSERVER
|   Version number: 11.00.7507.00
```
