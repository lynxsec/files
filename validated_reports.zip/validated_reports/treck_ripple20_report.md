# Ripple20 Treck Stack Exposure

## Description
Multiple internally reachable services respond with the distinctive TCP/IP fingerprint of the Treck networking stack that is vulnerable to the Ripple20 bug cluster (CVE‑2020‑11896 through CVE‑2020‑11914). Ripple20 vulnerabilities stem from Treck’s improper bounds and state handling inside fragmented IP, ICMP, and TCP traffic, enabling remote code execution or denial-of-service conditions on embedded devices. Because these services are exposed over the VPN, an adversary with basic network access can reliably identify Treck targets and deliver publicly available Ripple20 exploits.

## Observation
- `tcpdump` + `hping3` against `10.32.125.23:443` captured SYN+ACK responses with TTL 128, window 64240, MSS-only option, and sequential IP IDs—the canonical Treck signature.
- Identical fingerprints observed on `10.32.125.11:3389`, `10.32.125.14:3389`, `10.32.125.21:2000`, `10.32.124.66:80`, and `192.168.1.3:2000`.
- Management IP `10.32.124.1` remains filtered (no response) but was flagged in every scan; treat it as suspect until firmware confirmation is obtained.
- ICMP echo replies from Treck hosts return TTL 128, reinforcing the embedded-stack detection.
- IP-in-IP probe for CVE‑2020‑11898 is blocked by the perimeter gateway (ICMP Type 3 Code 2), so exploitation could not be reproduced from this vantage, but risk persists.

## Impact
- Remote code execution on embedded/IoT controllers leading to full device compromise.
- Network pivoting or credential theft if Treck devices serve as jump hosts (e.g., RDP endpoints).
- Service disruption (DoS) through crafted IP fragments triggering Treck crashes.

## Ease of Exploitation
**Moderate** – Ripple20 exploit kits are publicly documented; attacker must deliver crafted packets but fingerprinting requires no credentials.

## Affected Assets
- 10.32.124.1 *(filtered; review firmware)*
- 10.32.124.66
- 10.32.125.11
- 10.32.125.14
- 10.32.125.21
- 10.32.125.23
- 192.168.1.3

## CVSS v3.1
**Score:** 10.0 (Critical)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H`

## Recommendations
1. Identify the vendor/firmware version for each Treck-enabled device and apply Ripple20 patches or firmware upgrades immediately.
2. Restrict access to the exposed services (RDP, HTTP, custom port 2000) to hardened management subnets and enforce MFA where possible.
3. Monitor perimeter logs for IP-in-IP or unusual ICMP traffic indicative of Ripple20 exploitation attempts.
4. Retest after remediation to verify the Treck fingerprint no longer appears.

## References
- [JSOF Ripple20 Disclosure](https://www.jsof-tech.com/ripple20/)
- [Bosch PSIRT Advisory BOSCH-SA-662084](https://psirt.bosch.com/security-advisories/BOSCH-SA-662084.html)
- [HP Security Bulletin C06640149](https://support.hp.com/emea_africa-en/document/c06640149)

## Proof of Concept
```
# Packet capture plus SYN probe (10.32.125.23)
sudo timeout 5 tcpdump -i ens33 -nn -vv -c 1 'tcp and src host 10.32.125.23 and src port 443' &
sudo hping3 -S -p 443 -c 1 10.32.125.23
17:31:07.722343 IP 10.32.125.23.443 > 192.168.87.128.1890: Flags [S.], win 64240, options [mss 1460]
len=46 ip=10.32.125.23 ttl=128 id=44967 sport=443 flags=SA

# Additional Treck responders
sudo hping3 -S -p 3389 -c 1 10.32.125.11
sudo hping3 -S -p 3389 -c 1 10.32.125.14
sudo hping3 -S -p 2000 -c 1 10.32.125.21
sudo hping3 -S -p 80   -c 1 10.32.124.66
sudo hping3 -S -p 2000 -c 1 192.168.1.3

# Filtered management node (still in scope)
sudo hping3 -S -p 443 -c 1 10.32.124.1   # 100% packet loss

# ICMP TTL sample
ping -c 3 10.32.125.23
64 bytes from 10.32.125.23: icmp_seq=1 ttl=128 time=148 ms
```
