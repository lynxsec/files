# Vulnerability Summary

| Plugin ID | Vulnerability | Severity | CVSS v2 | Affected Hosts |
|-----------|--------------|----------|---------|----------------|
| 73756 | Microsoft SQL Server Unsupported Version Detection (remote check) | Critical | 10.0 | 10.32.124.66 |
| 137702 | Treck TCP/IP stack multiple vulnerabilities. (Ripple20) | Critical | 10.0 | 10.32.124.1, 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.21, 10.32.125.23, 192.168.1.3 |
| 12118 | Multiple BSD ipfw / ip6fw ECE Bit Filtering Evasion | High | 7.5 | 10.32.125.11, 10.32.125.21, 10.32.125.23 |
| 94437 | SSL 64-bit Block Size Cipher Suites Supported (SWEET32) | High | 5.0 | 10.32.124.66 |
| 175451 | Security Updates for Microsoft SQL Server (April 2023) | High | 7.5 | 10.32.124.66 |
| 171603 | Security Updates for Microsoft SQL Server (February 2023) | High | 9.0 | 10.32.124.66 |
| 106609 | Microsoft Windows IIS Default Index Page | Medium | 5.0 | 10.32.125.11, 10.32.125.23 |
| 51192 | SSL Certificate Cannot Be Trusted | Medium | 6.4 | 10.32.124.66, 10.32.125.11, 10.32.125.14 |
| 15901 | SSL Certificate Expiry | Medium | 5.0 | 10.32.124.66 |
| 35291 | SSL Certificate Signed Using Weak Hashing Algorithm | Medium | 5.0 | 10.32.124.66 |
| 45411 | SSL Certificate with Wrong Hostname | Medium | 5.0 | 10.32.124.66 |
| 57582 | SSL Self-Signed Certificate | Medium | 6.4 | 10.32.124.66, 10.32.125.11, 10.32.125.14 |
| 11618 | TCP/IP SYN+FIN Packet Filtering Weakness | Medium | 5.0 | 10.32.124.1, 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.21, 10.32.125.23, 192.168.1.3 |
| 12213 | TCP/IP Sequence Prediction Blind Reset Spoofing DoS | Medium | 5.0 | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.21, 10.32.125.23, 192.168.1.3 |
| 104743 | TLS Version 1.0 Protocol Detection | Medium | 6.1 | 10.32.124.66 |
| 157288 | TLS Version 1.1 Deprecated Protocol | Medium | 6.1 | 10.32.124.66 |
| 88099 | Web Server HTTP Header Information Disclosure | Medium | 5.0 | 10.32.125.11, 10.32.125.23 |
| 69551 | SSL Certificate Chain Contains RSA Keys Less Than 2048 bits | Low | — | 10.32.124.66 |
| 11157 | Trojan Horse Detection | Low | — | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.21 |
| 42799 | Broken Web Servers | None | — | 10.32.124.66 |
| 69482 | Microsoft SQL Server STARTTLS Support | None | — | 10.32.124.66 |
| 10674 | Microsoft SQL Server UDP Query Remote Version Disclosure | None | — | 10.32.124.66, 10.32.125.23 |
| 45410 | SSL Certificate 'commonName' Mismatch | None | — | 10.32.124.66 |
| 42981 | SSL Certificate Expiry - Future Expiry | None | — | 10.32.125.11 |
| 10863 | SSL Certificate Information | None | — | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.23 |
| 70544 | SSL Cipher Block Chaining Cipher Suites Supported | None | — | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.23 |
| 21643 | SSL Cipher Suites Supported | None | — | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.23 |
| 57041 | SSL Perfect Forward Secrecy Cipher Suites Supported | None | — | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.23 |
| 94761 | SSL Root Certification Authority Certificate Information | None | — | 10.32.124.66, 10.32.125.23 |
| 121010 | TLS Version 1.1 Protocol Detection | None | — | 10.32.124.66 |
| 136318 | TLS Version 1.2 Protocol Detection | None | — | 10.32.124.66, 10.32.125.11, 10.32.125.14, 10.32.125.23 |
| 11032 | Web Server Directory Enumeration | None | — | 10.32.124.66 |
| 11422 | Web Server Unconfigured - Default Install Page Present | None | — | 10.32.125.11, 10.32.125.23 |
