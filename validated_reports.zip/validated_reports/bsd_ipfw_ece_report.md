# ECN/ECE Filtering Bypass

## Description
The Explicit Congestion Notification (ECN) bit (ECE flag) should be stripped or validated by stateful firewalls. Three internal services accepted SYN packets with the ECE flag set and replied with successful SYN+ACK handshakes, demonstrating that ECN validation is not enforced. Attackers can abuse this gap to evade simple ACLs or fingerprint hosts that expect more defensive flag handling.

## Observation
- `tcp_ece_probe.py` executed against each target returned SYN+ACK with TTL 128, confirming acceptance of SYN+ECE packets.
- Affected ports: `10.32.125.11:80`, `10.32.125.21:2000`, `10.32.125.23:443`.

## Impact
- Enables firewall evasion by allowing non-standard flag combinations into protected services.
- Provides additional reconnaissance data to attackers crafting bespoke TCP exploitation chains.
- Increases the likelihood of stealthy brute-force or exploitation attempts against RDP/Splashtop.

## Ease of Exploitation
**Easy** – Crafting SYN+ECE packets requires only `scapy` or `hping3`; no credentials needed.

## Affected Assets
- 10.32.125.11
- 10.32.125.21
- 10.32.125.23

## CVSS v3.1
**Score:** 5.3 (Medium)  
**Vector:** `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N`

## Recommendations
1. Enable ECN-aware filtering or TCP normalization on perimeter and host firewalls to drop unexpected ECE/CWR combinations.
2. Review operating system hardening guides (e.g., BSD ipfw/ip6fw advisories) and apply any vendor ECN handling patches.
3. Add IDS rules to alert on SYN packets that carry ECE/CWR flags outside of controlled environments.

## References
- [FreeBSD Security Advisory (CVE-2001-0183)](https://www.freebsd.org/security/2001/dc.sack.txt)
- [Nessus Plugin 12118 – Multiple BSD ipfw/ip6fw ECE Bit Filtering Evasion](https://www.tenable.com/plugins/nessus/12118)

## Proof of Concept
```
python3 tcp_ece_probe.py --target 10.32.125.11 --port 80 --iface ens33
[*] Sending SYN with ECE to 10.32.125.11:80
[+] Received TCP packet from 10.32.125.11:80 with flags SA ttl=128

python3 tcp_ece_probe.py --target 10.32.125.21 --port 2000 --iface ens33
[+] Received TCP packet from 10.32.125.21:2000 with flags SA ttl=128

python3 tcp_ece_probe.py --target 10.32.125.23 --port 443 --iface ens33
[+] Received TCP packet from 10.32.125.23:443 with flags SA ttl=128
```
