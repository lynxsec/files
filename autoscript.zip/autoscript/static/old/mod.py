import argparse
import subprocess
import sys
import os
import json
import nmap
import time
import multiprocessing as mp
import difflib
from collections import OrderedDict

maindir = os.getcwd()+'/'
scandir = maindir + 'scan/'

def get_args():
	'''
	Gets all arguments from application
	'''
	parser = argparse.ArgumentParser(description='input ip')
	parser.add_argument('-i', '--ip', type=str, help='Ip / List of ips seperated by comma', default=False)
	parser.add_argument('-f', '--file', type=str, help='list of file with ips', default=False)
	parser.add_argument('-p', '--port', type=str, help='port', default=False)
	parser.add_argument('-x', '--exclude', type=str, help='exclude', default=False)
	parser.add_argument('-r', '--range', type=str, help='exclude', default='1-65535')
	parser.add_argument('-s', '--scan', help='port scan', action='store_true')\
	
	return parser

def get_ips(all_ips,file):
	'''
	Reads ip from -i flag or file using -f flag
	'''
	ips = []
	if all_ips:
		if ',' in all_ips:
			ips = all_ips.split(",")
		else:
			ips.append(all_ips)
	if file:
		with open(file,'r') as f:
			allips = f.readlines()
			for lines in allips:
				ips.append(lines.strip())
	return ips

def listener_scan(q):
    '''
    listens for messages on the q, writes to scan queue file. 
    '''
    with open(scandir+"queue.txt", 'a') as f:
        while 1:
            m = q.get()
            if m == 'kill':
                break
            for key,value in m.items():
            	for port in value:
            		f.write(key+':'+str(port)+'\n')
            		f.flush()


def portscan(ip,range_port):
	'''
	port scan script
	'''
	nmScan = nmap.PortScanner()
	nmScan.scan(ip, range_port)
	portserv = {}
	for host in nmScan.all_hosts():
		for proto in nmScan[host].all_protocols():
			for port in nmScan[host][proto].keys():
				portserv[port] = nmScan[host][proto][port]['name']

	return portserv.keys()

if __name__ == "__main__":
	pool = mp.Pool(1)
	global exclude
	global directory
	global manager
	global q
	manager = mp.Manager()
	q = manager.Queue()
	watcher = pool.apply_async(listener_scan, (q,))
	args = get_args().parse_args()
	all_ips = args.ip
	file = args.file
	port = args.port
	scan = args.scan
	range_port = args.range
	if args.exclude:
		exclude = args.exclude.split(",")
	else:
		exclude = []
	directory = os.getcwd()+'/'
	ips = get_ips(all_ips,file)
	if scan or port:
		if port:
			toscan = {}
			ports = []
			if ',' in port:
				ports = port.split(",")
			else:
				ports.append(port)
			for host in ips:
				toscan[host] = ports
			q.put(toscan)
		if scan:
			for host in ips:
				toscan = {}
				ports = []
				keys = portscan(host,range_port)
				for p in keys:
					ports.append(p)
				toscan[host] = ports
				q.put(toscan)
		q.put('kill')
	else:
		print('Specify a port or run port scan')
		parser = get_args()
		parser.print_help()

	pool.close()
	pool.join()
	
    # for key, value in toscan.items():
	# 	if isinstance(value, list):
	# 		for ports in value:
	# 			perform_checks(key, ports)
	# 	else:
	# 		perform_checks(key, value)
	# perform_checks(ips[0], 21)
	# print(ips)
