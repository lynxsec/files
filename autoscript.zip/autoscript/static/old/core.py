import argparse
import subprocess
import sys
import os
import json
import nmap
import time

def get_args():
	parser = argparse.ArgumentParser(description='input ip')
	parser.add_argument('-i', '--ip', type=str, help='Ip / List of ips seperated by comma', default=False)
	parser.add_argument('-f', '--file', type=str, help='list of file with ips', default=False)
	parser.add_argument('-p', '--port', type=str, help='port', default=False)
	parser.add_argument('-x', '--exclude', type=str, help='exclude', default=False)
	parser.add_argument('-s', '--scan', help='port scan', action='store_true')\
	
	return parser

def get_ips(all_ips,file):
	ips = []
	if all_ips:
		if ',' in all_ips:
			ips = all_ips.split(",")
		else:
			ips.append(all_ips)
	if file:
		with open(file,'r') as f:
			allips = f.readlines()
			for lines in allips:
				ips.append(lines.strip())
	return ips

def get_testcases(port):
	f = open(directory+'main.json')
	testcases = []
	data = json.load(f)
	for i in range(0,len(data)):
		if str(port) in data[i]['ports'].split(","):
			location = data[i]['location']
			testloc = open(directory+location)
			testcases = json.load(testloc)
	return testcases

def makeoutfolder(ip):
	dir_name = ip+'_scans/'
	try:
		os.mkdir(directory+'output/'+dir_name)
		print('Output directory created')
	except FileExistsError:
		pass 

def perform_checks(ip, port):
	testcasesdata = get_testcases(port)
	if testcasesdata:
		serv_name = testcasesdata['name']
		testcases = testcasesdata['command']
		makeoutfolder(ip)
		timestamp = int(time.time())
		for i in range(0,len(testcases)):
			if testcases[i]['tool'] not in exclude:
				output = directory+'output/'+ip+'_scans/'
				fileout = output+serv_name+'_'+ip+'_'+str(timestamp)
				static = directory+'static/'
				print("\n[+] Performing "+testcases[i]['tool']+" scan for " + ip + ":" + str(port))
				command = testcases[i]['command']
				command = command.replace("$port$",str(port)).replace("$host$",ip).replace("$out$",output).replace("$stat$",static).replace("$file$",fileout)
				print(command)
				subprocess.run(command, shell=True)

def portscan(ip):
	nmScan = nmap.PortScanner()
	nmScan.scan(ip, '1-65535')
	portserv = {}
	for host in nmScan.all_hosts():
		for proto in nmScan[host].all_protocols():
			for port in nmScan[host][proto].keys():
				portserv[port] = nmScan[host][proto][port]['name']

	# {'21':'ftp'}
	# ports = ['21','24']
	# ports = {5000: 'rtsp', 7000: 'rtsp'}
	return portserv.keys()

if __name__ == "__main__":
	global exclude
	global directory
	args = get_args().parse_args()
	all_ips = args.ip
	file = args.file
	port = args.port
	scan = args.scan
	if args.exclude:
		exclude = args.exclude.split(",")
	else:
		exclude = []
	directory = os.getcwd()+'/'
	toscan = {}
	ips = get_ips(all_ips,file)
	if scan or port:
		if scan:
			for host in ips:
				ports = []
				keys = portscan(host)
				for p in keys:
					ports.append(p)
				toscan[host] = ports
		if port:
			ports = []
			if ',' in port:
				ports = port.split(",")
			else:
				ports.append(port)
			if toscan:
				for key, value in toscan.items():
					for port in ports:
						if port not in value:
							value.append(port)
			else:
				for host in ips:
					toscan[host] = ports
	else:
		print('Specify a port or run port scan')
		parser = get_args()
		parser.print_help()
	print(toscan)
	for key, value in toscan.items():
		if isinstance(value, list):
			for ports in value:
				perform_checks(key, ports)
		else:
			perform_checks(key, value)
	# perform_checks(ips[0], 21)
	# print(ips)
