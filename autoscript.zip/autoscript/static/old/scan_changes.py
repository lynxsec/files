import os
import multiprocessing as mp
import time
import difflib
import queue
from collections import OrderedDict
import argparse
import subprocess
import sys
import os
import json
import nmap
import time

maindir = os.path.dirname(os.getcwd())+'/'
outdir = maindir+'scan/'

# def adder(times,queue_list,q,w,e):
#     while True:
#         time.sleep(times)
#         result = check(outdir+'done.txt',outdir+"queue.txt")
#         for ele in result:
#             if ele not in queue_list:
#                 queue_list.append(ele)
        # queue_tasks(result,queue_list,q,w,e)
        # print len(result)
        # if len(result) != 0:
        #     print(result)
        #     for ele in result:
        #         if q.empty():
        #             q.put(ele)
        #             pass
        #         elif w.empty():
        #             w.put(ele)
        #             pass
        #         elif e.empty():
        #             e.put(ele)
        #             pass
        #         else:
        #             time.sleep(5)
        # else:
        #     m.put('kill')

def adder(times,queue_list,q,w,e,doing):
    while True:
        time.sleep(10)
        if len(doing) == 0:
            result = check(outdir+'done.txt',outdir+"queue.txt")
            for ele in result:
                if ele not in queue_list.keys():
                    queue_list[ele] = 0
            # print(queue_list)
            for key,value in queue_list.items():
                if queue_list[key] == 0:
                    doing.append(key)
                    queue_list[key] = 1
            # print(doing)
            # print(queue_list)
                # ele = queue_list.pop(0)
                # doing.append(ele)

        else:
            print('Hi')
            print(doing)
            if q.empty():
                q.put(doing.pop(0))
            elif w.empty():
                w.put(doing.pop(0))
            elif e.empty():
                e.put(doing.pop(0))
            else:
                time.sleep(5)



    # print(queue_list)
    # if len(queue_list) == 0:
    #     for ele in result:
    #         if ele not in queue_list:
    #             queue_list.append(ele)
    # print(queue_list)
    # while len(queue_list) != 0:
    #     if q.empty():
    #         q.put(queue_list.pop(0))
    #     if w.empty():
    #         w.put(queue_list.pop(0))
    #     if e.empty():
    #         e.put(queue_list.pop(0))
    #     else:
    #         time.sleep(5)
    # doing = []
    # for ele in result:
    #     if ele not in queue_list:
    #         queue_list.append(ele)
    # if len(doing) == 0:
    #     for ele in queue_list:
    #         doing.append(ele)




def makeoutfolder(ip):
    dir_name = ip+'_scans/'
    try:
        os.mkdir(maindir+'output/'+dir_name)
        print('Output directory created')
    except FileExistsError:
        pass 

def perform_checks(ip, port,d):
    testcasesdata = get_testcases(port)
    exclude = []
    # print(testcasesdata)
    if testcasesdata:
        serv_name = testcasesdata['name']
        testcases = testcasesdata['command']
        makeoutfolder(ip)
        timestamp = int(time.time())
        with open(outdir+'exclude.txt','r') as f:
            temp = f.readlines()
        for line in temp:
            exclude.append(line.strip())
        print(exclude)
        for i in range(0,len(testcases)):
            if testcases[i]['tool'] not in exclude:
                output = maindir+'output/'+ip+'_scans/'
                fileout = output+serv_name+'_'+ip+'_'+str(timestamp)
                static = maindir+'static/'
                print("\n[+] Performing "+testcases[i]['tool']+" scan for " + ip + ":" + str(port))
                command = testcases[i]['command']
                command = command.replace("$port$",str(port)).replace("$host$",ip).replace("$out$",output).replace("$stat$",static).replace("$file$",fileout)
                print(command)
                time.sleep(5)
                subprocess.run(command, shell=True)
        d.put(ip+':'+port)
    else:
        d.put(ip+':'+port)

def get_testcases(port):
    # print(maindir)
    f = open(maindir+'main.json')
    testcases = []
    data = json.load(f)
    for i in range(0,len(data)):
        if str(port) in data[i]['ports'].split(","):
            location = data[i]['location']
            testloc = open(maindir+location)
            testcases = json.load(testloc)
    return testcases

def uniquelines(lineslist):
    unique = {}
    result = []
    for item in lineslist:
        if item.strip() in unique: continue
        unique[item.strip()] = 1
        result.append(item)
    return result

def main_listener(m,q,w,e):
    '''listens for messages on the q, writes to file. '''
    # print "listener initiated"
    while 1:
        message = m.get()
        print(message)
        assigned = 0
        print(q.empty())
        print(w.empty())
        print(e.empty())
        if q.empty():
            # try:
            #     q.get(True,0.1)
            # except queue.Empty: # queue here refers to the module, not a class
            q.put(message)
                # assigned = 1
        elif w.empty():
            # try:
            #     w.get(True,0.1)
            # except queue.Empty: # queue here refers to the module, not a class
            #     # print('HI')
            w.put(message)
                # assigned = 1
        elif e.empty():
            # try:
            #     e.get(True,0.1)
            # except queue.Empty: # queue here refers to the module, not a class
            #     # print('HI')
            e.put(message)
                # assigned = 1

def listener1(q,d):
    '''listens for messages on the q, writes to file. '''
    # print "listener initiated"
    while 1:
        m = q.get()
        print(m+' in queue q')
        if m == 'kill':
            break
        ip,port = m.split(':')
        perform_checks(ip, port,d)

def listener2(w,d):
    '''listens for messages on the q, writes to file. '''
    # print "listener initiated"
    while 1:
        m = w.get()
        print(m+' in queue w')
        if m == 'kill':
            break
        ip,port = m.split(':')
        perform_checks(ip,port,d)

def listener3(e,d):
    '''listens for messages on the q, writes to file. '''
    # print "listener initiated"
    while 1:
        m = e.get()
        print(m+' in queue e')
        if m == 'kill':
            break
        ip,port = m.split(':')
        perform_checks(ip, port,d)

def listener_done(d):
    '''listens for messages on the q, writes to file. '''
    # print "listener initiated"
    with open(outdir+"done.txt", 'a') as f:
        while 1:
            m = d.get()
            if m == 'kill':
                break
            f.write(str(m) + '\n')
            f.flush()


def check(done,queue):
    # print "Hi"
    file1 = open(done,"r") 
    f1 = [x.strip() for x in file1.readlines()]
    # file2 = open("./output/vimeo.com/assetfinder.txt","r")
    file2 = open(queue,"r")
    f2 = [x.strip() for x in file2.readlines()]

    f1.sort()
    f2.sort()

    result = []
    diff = difflib.ndiff(uniquelines(f1), uniquelines(f2))
    #print diff
    changes = [l for l in diff if l.startswith('+ ')] #check if there are new items/subdomains
    # print changes
    newdiff = []

    for c in changes:
        c = c \
        .replace('+ ', '') \
        .replace('*.', '') \
        .replace('\n', '')
        result.append(c)
        
    result = list(set(result))

    return result

def main():
    pool = mp.Pool(6)
    global manager
    global q
    global d,m,w,e
    global queue_list
    queue_list = {}
    manager = mp.Manager()
    q = manager.Queue()
    d = manager.Queue()
    m = manager.Queue()
    w = manager.Queue()
    e = manager.Queue()
    doner = pool.apply_async(listener_done, (d,))
    add = pool.apply_async(adder, (10,queue_list,q,w,e,[]))
    # watcher = pool.apply_async(main_listener, (m,q,w,e))
    watcher1 = pool.apply_async(listener1, (q,d))
    watcher2 = pool.apply_async(listener2, (w,d))
    watcher3 = pool.apply_async(listener3, (e,d))
    pool.close()
    pool.join()

if __name__ == '__main__':
    main()
