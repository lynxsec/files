</html>
<form action="" method="post">
<input type="text" name="host" id="host" value="Host input">
<input type="checkbox" id="scan" name="scan" value="scan">
<label for="scan"> Do Port Scan</label><br>
<input type="checkbox" id="portscan"  onclick="addbox();">Scan specific port
<input type="text" name="port" id="port" value="Port input" style="display: none;">
<button type="submit" name="ok" onclick='addscan()'>OK</button>
</form>
<script type="text/javascript">
function addbox() {
if (document.getElementById('portscan').checked) {
        document.getElementById('port').style.display = 'block';
    } else {
        document.getElementById('port').style.display = 'none';
    }}
function addscan() {
	if (document.getElementById('scan').checked)
	{
		host = document.getElementById('scan').value
		console.log(host)
	}
	if (document.getElementById('portscan').checked)
	{
		host = document.getElementById('scan').value
		console.log(host)
	}

}
</script>
</html>