# autoscript - Automated Enumeration Script

*Autoscript initates portscan and automatically enumerates various scripts and tools for each port or service on the host.*

## Installation

### Installation of autoscript

1. Clone the repository
2. Make sure you have python3 and pip3 installed
3. run pip3 install -r requirements.txt
4. Make sure you have installed all additional tools mentioned for each service listed below

Thats it!

## Usage

```sh
usage: autoscript.py [-h] [-i IP] [-f FILE] [-p PORT] [-x EXCLUDE] [-r RANGE] [-s]

Autoscript Enumeration

optional arguments:
  -h, --help            show this help message and exit
  -i IP, --ip IP        Ip / list of ips seperated by comma
  -f FILE, --file FILE  List of file with ips
  -p PORT, --port PORT  secific port / list of ports seperated by comma
  -x EXCLUDE, --exclude EXCLUDE
                        tools to exclude from scan
  -r RANGE, --range RANGE
                        ports range
  -s, --scan            do port scan
```

Start the scan.py script in the scan directory or use the command to use it in tmux. This script will use a multithreaded queue to give faster scan results.

```tmux new-session -s scan -d && tmux send -t scan:0.0 "python3 scan/scan.py" C-m```

### Use the script autoscript.py to begin scans

Some usage types:
```sh
python3 autoscript.py -i 192.168.0.104,192.168.0.103 -f ipfile.txt -s
python3 autoscript.py -i 192.168.0.104  -s -p 21 -r 1-1000
python3 autoscript.py -i 192.168.0.103 -p 25 -x metasploit,hydra
```

Results will be stored in **output** folder under name **host_scans/**

## Adding your own template

1. Modify the main.json file to insert service name, port and location of testcases file

Example:
```json
{
	"name":"ftp",
	"ports":"21",
	"location":"/static/ftp/ftp.json"
}
```
2. At location mentioned, host the file with testcases (in this case ftp.json). Following placeholders are supported for each script
 - $host$ -> host/ip to be used for test
 - $port$ -> port to be tested
 - $out$ -> output folder location
 - $stat$ -> static folder location to call any files from service folder
 - $file$ -> file name output in shared folder to simplfy naming convention (used as following: output-folder/service_ip_timestamp)

 Example:
 ```json
 {
		"name":"ssh",
		"command":[
			{
				"tool":"ssh-audit",
				"command": "python3 ~/tools/ssh-audit/ssh-audit.py $host$ >> $file$_ssh-audit.txt",
				"references": "ssh-audit"
			},
			{
				"tool":"ssh-keyscan",
				"command": "ssh-keyscan -t rsa $host$ -p $port$ >> '$file$_public_key.txt'",
				"references": "public ssh key"
			},
			{
				"tool":"nmap",
				"command":"nmap -p$port$ -sC -sV --script=ssh-auth-methods,ssh-hostkey,ssh2-enum-algos -script-args=ssh.user=root,ssh_hostkey=full $host$ -oG $file$_nmap_scan.txt",
				"references":"retrieve supported algos"
			}
		]
}
 ```
