import os
import multiprocessing as mp
import time
import difflib
import queue
from collections import OrderedDict
import argparse
import subprocess
import sys
import os
import json
import time
import requests
from urllib.parse import urlparse, urlunparse

maindir = os.path.dirname(os.getcwd())+'/'
outdir = maindir+'check/'
scandir = maindir+'scan/'

def get_args():
	'''
	Gets all arguments from application
	'''
	parser = argparse.ArgumentParser(description='Check for new files')
	parser.add_argument('-u', '--url', type=str, help='Url to check for json files', default=False)
	
	return parser

def get_file_contents(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:98.0) Gecko/20100101 Firefox/98.0','Cache-Control': 'no-cache','Pragma': 'no-cache'}
	r = requests.get(url, headers=headers)
	return r

def check_new_file(url):
	content_text = get_file_contents(url)
	content = content_text.text.split('\n')
	file_contents = []
	toscan = []
	with open(outdir+'queue.txt','r') as f:
		file = f.readlines()
		for lines in file:
			file_contents.append(lines.strip())
	for line in content:
		if line not in file_contents:
			toscan.append(line)
	return toscan

def initiate_scan(resp):
	host = resp['config'][0]['host']
	port = resp['config'][0]['port']
	scan = resp['config'][0]['scan']
	scriptscan = resp['config'][0]['scriptscan']
	command = 'python3 '+maindir+'autoscript.py -i '+host
	if scriptscan:
		command = command + ' -p '+str(port)
	if scan:
		command = command + ' -s '
	print("\n[+] Performing scan for " + host)
	time.sleep(5)
	subprocess.run(command, shell=True)

def get_json_files(url,file,q):
	path2 = urlparse(url)
	temp = os.path.split(urlparse(url).path)
	temp2 = list(temp)
	temp2[1] = file
	json_file_path = temp2[0] + '/' + temp2[1]
	json_file_url = urlunparse(path2._replace(path=json_file_path))
	resp = get_file_contents(json_file_url)
	resp = resp.json()
	initiate_scan(resp)
	q.put(file)

def checker(times,q,url):
    while True:
        time.sleep(times)
        toscan = check_new_file(url)
        if toscan:
        	for ele in toscan:
        		if ele != '':
        			print('new file found '+ele)
        			get_json_files(url,ele,q)
        else:
            pass

def listener_done(q):
    '''listens for messages on the q, writes to file. '''
    with open(outdir+"queue.txt", 'a') as f:
        while 1:
            m = q.get()
            if m == 'kill':
                break
            f.write(str(m) + '\n')
            f.flush()

if __name__ == "__main__":
	pool = mp.Pool(2)
	global manager
	global q
	manager = mp.Manager()
	q = manager.Queue()
	args = get_args().parse_args()
	url = args.url
	doner = pool.apply_async(listener_done, (q,))
	add = pool.apply_async(checker, (10,q,url))
	pool.close()
	pool.join()





